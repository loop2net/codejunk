﻿Imports System.IO

Public Class Form1
    Dim filename As String = ""
    Dim i As Integer = 0

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim img As Bitmap


        i = 0

        Me.WindowState = FormWindowState.Minimized

        Threading.Thread.Sleep(2000)


        If Int(txtsnaps.Text) < 999 Then



            For i = 1 To Int(txtsnaps.Text) Step 1

                SendKeys.Send("{PRTSC}")
                PictureBox1.Image = Clipboard.GetImage
                
                filename = "images\" & Str(i) & ".jpg"
                PictureBox1.Image.Save(filename)


            Next

            Me.WindowState = FormWindowState.Normal

            MsgBox("DONE")

        Else

        End If
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        If PictureBox1.Image IsNot Nothing Then
            Clipboard.SetImage(PictureBox1.Image)
            MsgBox("Image copied to clipboard")

        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Directory.Exists("images") Then

        Else
            MkDir(CurDir() & "\images")
        End If
    End Sub


End Class
